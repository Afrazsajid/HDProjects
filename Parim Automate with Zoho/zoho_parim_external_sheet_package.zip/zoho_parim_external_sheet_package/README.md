# H&D Zoho WorkDrive to PARiM Google Sheet Transformer

This version reads from `sheet1` in the source Google Sheet and writes the transformed PARiM format into a different existing Google Sheet file.

## Files

- `Code.gs` - Google Apps Script web app.
- `transform_sheet1_to_external_parim_sheet.py` - Python transformer.
- `.env.example` - Rename to `.env` and fill credentials.

## Apps Script Setup

1. Open the source Google Sheet that contains `sheet1`.
2. Go to Extensions > Apps Script.
3. Paste `Code.gs`.
4. Change `API_TOKEN`.
5. Set `TARGET_SPREADSHEET_ID` to the ID of the other existing Google Sheet.
6. Set `TARGET_SHEET_NAME` to the tab name in that target sheet, for example `sheet1` or `Parim Import`.
7. Deploy > New deployment > Web app.
8. Execute as: Me.
9. Who has access: Anyone.
10. Copy the `/exec` URL into `.env`.

## Getting Google Sheet ID

From this URL:

`https://docs.google.com/spreadsheets/d/1ABCxyz123456789/edit`

The spreadsheet ID is:

`1ABCxyz123456789`

## Python Setup

```cmd
pip install requests python-dotenv
```

Rename `.env.example` to `.env` and fill all values.

Run:

```cmd
python transform_sheet1_to_external_parim_sheet.py
```

## What it does

- Reads all rows from source `sheet1`.
- Transforms them into PARiM format.
- Finds any Zoho WorkDrive file link in document columns.
- Gets the parent WorkDrive folder link.
- Writes final data into the target Google Sheet file.

## Privacy

The script does not create public links. It only writes the normal WorkDrive folder link. Users still need Zoho permission to open the folder.
