/****************************************************
 * H&D PARiM Transformer Bridge
 * Google Apps Script Web App
 *
 * Purpose:
 * 1) Python reads source data from SOURCE_SHEET_NAME, usually sheet1.
 * 2) Python transforms data into PARiM format.
 * 3) Python writes transformed rows into a DIFFERENT existing Google Sheet file.
 *
 * Deploy as Web App:
 * Execute as: Me
 * Who has access: Anyone
 ****************************************************/

const CONFIG = {
  API_TOKEN: 'CHANGE_THIS_TO_A_LONG_SECRET_TOKEN_12345',

  // SOURCE_SPREADSHEET_ID:
  // Leave blank if this Apps Script is attached to the source Google Sheet.
  // Or paste the source spreadsheet ID if this is a standalone script.
  SOURCE_SPREADSHEET_ID: '',
  SOURCE_SHEET_NAME: 'sheet1',

  // TARGET_SPREADSHEET_ID:
  // Paste the ID of the different existing Google Sheet where PARiM data should go.
  TARGET_SPREADSHEET_ID: 'PASTE_TARGET_GOOGLE_SHEET_ID_HERE',
  TARGET_SHEET_NAME: 'sheet1'
};

function doGet(e) {
  try {
    checkToken_(e);

    const action = (e.parameter.action || '').trim();

    if (action === 'readSource') {
      return json_({ ok: true, data: readSource_() });
    }

    return json_({ ok: false, error: 'Unknown GET action. Use action=readSource' });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function doPost(e) {
  try {
    checkToken_(e);

    const action = (e.parameter.action || '').trim();

    if (action === 'writeTarget') {
      const body = JSON.parse(e.postData.contents || '{}');
      const result = writeTarget_(body.headers || [], body.rows || []);
      return json_({ ok: true, data: result });
    }

    return json_({ ok: false, error: 'Unknown POST action. Use action=writeTarget' });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function checkToken_(e) {
  const token = e && e.parameter ? e.parameter.token : '';

  if (!token || token !== CONFIG.API_TOKEN) {
    throw new Error('Unauthorised. Invalid or missing token.');
  }
}

function getSourceSpreadsheet_() {
  if (CONFIG.SOURCE_SPREADSHEET_ID && CONFIG.SOURCE_SPREADSHEET_ID.trim()) {
    return SpreadsheetApp.openById(CONFIG.SOURCE_SPREADSHEET_ID.trim());
  }

  return SpreadsheetApp.getActiveSpreadsheet();
}

function readSource_() {
  const ss = getSourceSpreadsheet_();
  const sheet = ss.getSheetByName(CONFIG.SOURCE_SHEET_NAME);

  if (!sheet) {
    throw new Error('Source sheet not found: ' + CONFIG.SOURCE_SHEET_NAME);
  }

  const values = sheet.getDataRange().getValues();

  if (!values || values.length === 0) {
    return {
      headers: [],
      rows: []
    };
  }

  const headers = values[0].map(function (h) {
    return String(h || '').trim();
  });

  const rows = values.slice(1).filter(function (row) {
    return row.some(function (cell) {
      return String(cell || '').trim() !== '';
    });
  });

  return {
    headers: headers,
    rows: rows
  };
}

function writeTarget_(headers, rows) {
  if (!CONFIG.TARGET_SPREADSHEET_ID || CONFIG.TARGET_SPREADSHEET_ID === 'PASTE_TARGET_GOOGLE_SHEET_ID_HERE') {
    throw new Error('TARGET_SPREADSHEET_ID is not set in CONFIG.');
  }

  if (!headers || headers.length === 0) {
    throw new Error('No target headers received from Python.');
  }

  const targetSs = SpreadsheetApp.openById(CONFIG.TARGET_SPREADSHEET_ID.trim());
  let targetSheet = targetSs.getSheetByName(CONFIG.TARGET_SHEET_NAME);

  if (!targetSheet) {
    targetSheet = targetSs.insertSheet(CONFIG.TARGET_SHEET_NAME);
  }

  const output = [headers].concat(rows || []);

  targetSheet.clearContents();
  targetSheet.clearFormats();

  const range = targetSheet.getRange(1, 1, output.length, headers.length);

  // Keep everything as text. This helps preserve mobile numbers, sort codes and leading zeros.
  range.setNumberFormat('@');
  range.setValues(output);

  targetSheet.setFrozenRows(1);
  targetSheet.autoResizeColumns(1, headers.length);

  return {
    targetSpreadsheetId: CONFIG.TARGET_SPREADSHEET_ID,
    targetSheetName: CONFIG.TARGET_SHEET_NAME,
    rowsWritten: rows.length,
    columnsWritten: headers.length
  };
}

function json_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
