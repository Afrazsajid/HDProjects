const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

const body = document.body;
const menuButton = $(".menu-toggle");
const menuLabel = $(".menu-toggle .sr-only");
const mobileMenu = $(".mobile-menu");
const progressBar = $(".scroll-progress span");
const siteHeader = $(".site-header");

function syncBodyLock() {
  const locked =
    mobileMenu.classList.contains("is-open") ||
    $(".lead-sheet").classList.contains("is-open") ||
    $(".reel-modal").classList.contains("is-open");
  body.classList.toggle("has-overlay", locked);
}

function closeMenu() {
  menuButton.setAttribute("aria-expanded", "false");
  menuLabel.textContent = "Open menu";
  mobileMenu.setAttribute("aria-hidden", "true");
  mobileMenu.classList.remove("is-open");
  syncBodyLock();
}

menuButton.addEventListener("click", () => {
  const opening = menuButton.getAttribute("aria-expanded") !== "true";
  menuButton.setAttribute("aria-expanded", String(opening));
  menuLabel.textContent = opening ? "Close menu" : "Open menu";
  mobileMenu.setAttribute("aria-hidden", String(!opening));
  mobileMenu.classList.toggle("is-open", opening);
  syncBodyLock();
});

$$(".mobile-menu a").forEach((link) => link.addEventListener("click", closeMenu));

requestAnimationFrame(() => {
  window.setTimeout(() => body.classList.add("is-ready"), reducedMotion ? 0 : 120);
});

let scrollQueued = false;
function updateScrollProgress() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  const ratio = scrollable > 0 ? Math.min(window.scrollY / scrollable, 1) : 0;
  progressBar.style.transform = `scaleX(${ratio})`;
  siteHeader.classList.toggle("is-scrolled", window.scrollY > 24);
  scrollQueued = false;
}

window.addEventListener(
  "scroll",
  () => {
    if (!scrollQueued) {
      scrollQueued = true;
      requestAnimationFrame(updateScrollProgress);
    }
  },
  { passive: true },
);
updateScrollProgress();

const revealElements = $$("[data-reveal]");
if (reducedMotion || !("IntersectionObserver" in window)) {
  revealElements.forEach((element) => element.classList.add("is-visible"));
} else {
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -6% 0px" },
  );
  revealElements.forEach((element) => revealObserver.observe(element));
}

function initialiseDust() {
  const canvas = $("#dust-canvas");
  if (!canvas || reducedMotion) return;

  const context = canvas.getContext("2d");
  const hero = $(".hero");
  let particles = [];
  let heroVisible = true;
  let animationFrame;

  function resize() {
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
    const rect = hero.getBoundingClientRect();
    canvas.width = Math.round(rect.width * ratio);
    canvas.height = Math.round(rect.height * ratio);
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    const count = window.innerWidth < 760 ? 18 : 34;
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * rect.width,
      y: Math.random() * rect.height,
      radius: Math.random() * 1.4 + 0.35,
      speed: Math.random() * 0.18 + 0.05,
      drift: Math.random() * 0.12 - 0.06,
      alpha: Math.random() * 0.5 + 0.1,
    }));
  }

  function draw() {
    if (!heroVisible) {
      animationFrame = requestAnimationFrame(draw);
      return;
    }

    const width = hero.clientWidth;
    const height = hero.clientHeight;
    context.clearRect(0, 0, width, height);
    particles.forEach((particle) => {
      particle.y -= particle.speed;
      particle.x += particle.drift;
      if (particle.y < -4) particle.y = height + 4;
      if (particle.x < -4) particle.x = width + 4;
      if (particle.x > width + 4) particle.x = -4;
      context.beginPath();
      context.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      context.fillStyle = `rgba(240, 205, 125, ${particle.alpha})`;
      context.fill();
    });
    animationFrame = requestAnimationFrame(draw);
  }

  const heroObserver = new IntersectionObserver(
    ([entry]) => {
      heroVisible = entry.isIntersecting;
    },
    { threshold: 0 },
  );
  heroObserver.observe(hero);
  resize();
  draw();
  window.addEventListener("resize", resize, { passive: true });
  window.addEventListener("pagehide", () => cancelAnimationFrame(animationFrame), { once: true });
}
initialiseDust();

const pointExperience = $("[data-manifesto]");
const pointVisual = $(".manifesto-visual");
const pointLens = $(".manifesto-lens");
const pointRange = $("#point-range");
const pointMeasure = $("#point-measure");
const pointNumber = $("#point-number");
const pointTitle = $("#point-title");
const pointCopy = $("#point-copy");
const pointPrinciple = $(".manifesto-principle");
const pointSection = $("#point-of-view");
const pointButtons = $$(".manifesto-stations button");
const pointStations = [12, 50, 88];
const pointMessages = [
  {
    title: "Measured to the millimetre.",
    copy: "No fillers. No awkward gaps. Every line is designed to belong to the room.",
    valueText: "Fit: measured to the millimetre",
  },
  {
    title: "Built around how you live.",
    copy: "Storage begins with what you own and reach for—not a standard internal layout.",
    valueText: "Life: built around how you live",
  },
  {
    title: "The whole room feels resolved.",
    copy: "That is the difference between fitted furniture and fitted architecture.",
    valueText: "Feeling: the whole room feels resolved",
  },
];
let activePoint = 0;

function closestPointIndex(value) {
  return pointStations.reduce(
    (closest, station, index) =>
      Math.abs(station - value) < Math.abs(pointStations[closest] - value) ? index : closest,
    0,
  );
}

function updatePointCopy(index) {
  if (index === activePoint && pointTitle.textContent === pointMessages[index].title) return;
  activePoint = index;
  const message = pointMessages[index];
  pointNumber.textContent = `${String(index + 1).padStart(2, "0")} / 03`;
  pointTitle.textContent = message.title;
  pointCopy.textContent = message.copy;
  pointRange.setAttribute("aria-valuetext", message.valueText);
  pointButtons.forEach((button, buttonIndex) => {
    const selected = buttonIndex === index;
    button.classList.toggle("is-active", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
  pointPrinciple.classList.remove("is-changing");
  void pointPrinciple.offsetWidth;
  pointPrinciple.classList.add("is-changing");
}

function renderPointLens(value) {
  const numericValue = Math.max(0, Math.min(100, Number(value)));
  const rect = pointVisual.getBoundingClientRect();
  const baseRadius = Math.min(82, Math.max(66, window.innerWidth * 0.21));
  const expansion = Math.max(0, Math.min(1, (numericValue - 68) / 20));
  const coverRadius = Math.hypot(rect.width, rect.height) + 24;
  const radius = baseRadius + (coverRadius - baseRadius) * expansion;
  const blueprintOpacity = 1 - expansion;
  const edgeInset = Math.min(25, (baseRadius / rect.width) * 100 + 2);
  const visualPosition = edgeInset + (numericValue / 100) * (100 - edgeInset * 2);

  pointExperience.style.setProperty("--lens-x", `${visualPosition}%`);
  pointExperience.style.setProperty("--lens-radius", `${Math.round(radius)}px`);
  pointExperience.style.setProperty("--blueprint-opacity", blueprintOpacity.toFixed(2));
  pointExperience.style.setProperty("--range-progress", `${numericValue}%`);
  pointMeasure.textContent = `${String(Math.round((numericValue / 100) * 2874)).padStart(4, "0")} MM`;
  pointExperience.classList.toggle("is-resolved", expansion > 0.94);
  pointSection.classList.toggle("is-resolved", expansion > 0.94);
  updatePointCopy(closestPointIndex(numericValue));
}

pointRange.addEventListener("input", () => renderPointLens(pointRange.value));

function snapPointRange() {
  const index = closestPointIndex(Number(pointRange.value));
  pointRange.value = String(pointStations[index]);
  renderPointLens(pointStations[index]);
}

pointRange.addEventListener("pointerup", snapPointRange);
pointRange.addEventListener("pointercancel", snapPointRange);

let pointLensDragging = false;

function pointValueFromClientX(clientX) {
  const rect = pointVisual.getBoundingClientRect();
  const baseRadius = Math.min(82, Math.max(66, window.innerWidth * 0.21));
  const edgeInset = Math.min(25, (baseRadius / rect.width) * 100 + 2);
  const visualPercent = ((clientX - rect.left) / rect.width) * 100;
  return Math.max(0, Math.min(100, ((visualPercent - edgeInset) / (100 - edgeInset * 2)) * 100));
}

pointLens.addEventListener("pointerdown", (event) => {
  pointLensDragging = true;
  pointExperience.classList.add("is-dragging");
  pointLens.setPointerCapture(event.pointerId);
  pointRange.value = String(Math.round(pointValueFromClientX(event.clientX)));
  renderPointLens(pointRange.value);
});

pointLens.addEventListener("pointermove", (event) => {
  if (!pointLensDragging) return;
  pointRange.value = String(Math.round(pointValueFromClientX(event.clientX)));
  renderPointLens(pointRange.value);
});

function finishPointLensDrag(event) {
  if (!pointLensDragging) return;
  pointLensDragging = false;
  pointExperience.classList.remove("is-dragging");
  if (pointLens.hasPointerCapture(event.pointerId)) pointLens.releasePointerCapture(event.pointerId);
  snapPointRange();
}

pointLens.addEventListener("pointerup", finishPointLensDrag);
pointLens.addEventListener("pointercancel", finishPointLensDrag);

pointButtons.forEach((button, index) => {
  button.addEventListener("click", () => {
    pointRange.value = String(pointStations[index]);
    renderPointLens(pointStations[index]);
  });
});

window.addEventListener("resize", () => renderPointLens(pointRange.value), { passive: true });
renderPointLens(pointRange.value);

const sceneVisual = $(".scene-builder__visual");
const sceneImage = $("#scene-image");
const sceneName = $("#scene-name");
const sceneNumber = $("#scene-number");

$$(".finish-chip").forEach((button) => {
  button.addEventListener("click", () => {
    if (button.classList.contains("is-active")) return;
    $$(".finish-chip").forEach((chip) => {
      chip.classList.remove("is-active");
      chip.setAttribute("aria-pressed", "false");
    });
    button.classList.add("is-active");
    button.setAttribute("aria-pressed", "true");
    sceneVisual.classList.add("is-switching");

    window.setTimeout(() => {
      sceneImage.src = button.dataset.image;
      sceneImage.alt = `${button.dataset.name} fitted furniture concept`;
      sceneName.textContent = button.dataset.name;
      sceneNumber.textContent = button.dataset.number;
      sceneImage.addEventListener(
        "load",
        () => {
          sceneVisual.classList.remove("is-switching");
        },
        { once: true },
      );
    }, reducedMotion ? 0 : 220);
  });
});

const lightToggle = $(".light-toggle");
lightToggle.addEventListener("click", () => {
  const lightOn = lightToggle.getAttribute("aria-pressed") === "true";
  lightToggle.setAttribute("aria-pressed", String(!lightOn));
  lightToggle.classList.toggle("is-on", !lightOn);
  sceneVisual.classList.toggle("is-dim", lightOn);
});

const leadSheet = $(".lead-sheet");
const leadPanel = $(".lead-sheet__panel");
const leadForm = $("#lead-form");
const leadProgress = $(".lead-progress");
const progressSegments = $$(".lead-progress > span");
const stepNumber = $("#step-number");
const formSteps = $$(".form-step");
const formComplete = $(".form-complete");
let currentStep = 1;
let leadReturnFocus = null;

function showStep(step) {
  currentStep = step;
  formSteps.forEach((fieldset) => {
    fieldset.classList.toggle("is-active", Number(fieldset.dataset.step) === step);
  });
  progressSegments.forEach((segment, index) => {
    segment.classList.toggle("is-active", index < step);
  });
  stepNumber.textContent = String(step);
  leadPanel.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
}

function validateStep(step) {
  const fieldset = $(`.form-step[data-step="${step}"]`);
  const requiredFields = $$("[required]", fieldset);
  for (const field of requiredFields) {
    if (!field.checkValidity()) {
      field.reportValidity();
      return false;
    }
  }
  return true;
}

function resetLeadForm() {
  leadForm.reset();
  formComplete.classList.remove("is-visible");
  leadProgress.hidden = false;
  showStep(1);
}

function openLead(event) {
  leadReturnFocus = event?.currentTarget || document.activeElement;
  closeMenu();
  leadSheet.setAttribute("aria-hidden", "false");
  leadSheet.classList.add("is-open");
  syncBodyLock();
  window.setTimeout(() => $(".sheet-close").focus(), reducedMotion ? 0 : 480);
}

function closeLead() {
  leadSheet.setAttribute("aria-hidden", "true");
  leadSheet.classList.remove("is-open");
  syncBodyLock();
  if (leadReturnFocus && typeof leadReturnFocus.focus === "function") leadReturnFocus.focus();
  if (formComplete.classList.contains("is-visible")) {
    window.setTimeout(resetLeadForm, reducedMotion ? 0 : 480);
  }
}

$$("[data-open-lead]").forEach((button) => button.addEventListener("click", openLead));
$$("[data-close-lead]").forEach((button) => button.addEventListener("click", closeLead));

$$(".step-next").forEach((button) => {
  button.addEventListener("click", () => {
    if (validateStep(currentStep)) showStep(Math.min(currentStep + 1, 3));
  });
});

$$(".step-back").forEach((button) => {
  button.addEventListener("click", () => showStep(Math.max(currentStep - 1, 1)));
});

leadForm.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!validateStep(3)) return;
  formSteps.forEach((fieldset) => fieldset.classList.remove("is-active"));
  leadProgress.hidden = true;
  formComplete.classList.add("is-visible");
  formComplete.focus();
});

const reelModal = $(".reel-modal");
const reelImage = $("#reel-image");
const reelCaption = $("#reel-caption");
const reelCount = $("#reel-count");
const reelBars = $$(".reel-bars i");
const reelItems = [
  { image: "assets/sliding-opt.webp", caption: "Spaces made calm." },
  { image: "assets/walk-in-opt.webp", caption: "Every detail, considered." },
  { image: "assets/loft-opt.webp", caption: "Awkward angles, beautifully resolved." },
  { image: "assets/office-opt.webp", caption: "A place for everything." },
];
let reelIndex = 0;
let reelTimer;
let reelReturnFocus = null;

function renderReel(index) {
  reelIndex = (index + reelItems.length) % reelItems.length;
  const item = reelItems[reelIndex];
  reelImage.src = item.image;
  reelCaption.textContent = item.caption;
  reelCount.textContent = `${String(reelIndex + 1).padStart(2, "0")} / 04`;
  reelBars.forEach((bar, barIndex) => bar.classList.toggle("is-active", barIndex <= reelIndex));
  reelImage.style.animation = "none";
  void reelImage.offsetWidth;
  reelImage.style.animation = "";
}

function startReel() {
  window.clearInterval(reelTimer);
  if (!reducedMotion) {
    reelTimer = window.setInterval(() => renderReel(reelIndex + 1), 2800);
  }
}

function openReel(event) {
  reelReturnFocus = event.currentTarget;
  reelModal.setAttribute("aria-hidden", "false");
  reelModal.classList.add("is-open");
  renderReel(0);
  startReel();
  syncBodyLock();
  window.setTimeout(() => $(".reel-modal__close").focus(), reducedMotion ? 0 : 350);
}

function closeReel() {
  window.clearInterval(reelTimer);
  reelModal.setAttribute("aria-hidden", "true");
  reelModal.classList.remove("is-open");
  syncBodyLock();
  if (reelReturnFocus) reelReturnFocus.focus();
}

$$("[data-open-reel]").forEach((button) => button.addEventListener("click", openReel));
$$("[data-close-reel]").forEach((button) => button.addEventListener("click", closeReel));
$(".reel-modal__frame").addEventListener("click", () => {
  renderReel(reelIndex + 1);
  startReel();
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  if (reelModal.classList.contains("is-open")) closeReel();
  else if (leadSheet.classList.contains("is-open")) closeLead();
  else if (mobileMenu.classList.contains("is-open")) closeMenu();
});
